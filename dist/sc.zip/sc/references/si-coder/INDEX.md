# Bundled SI-Coder workflows

This directory is generated for the standalone web/import package. The canonical editable sources live in the repository's `skills/` and `references/` directories.

- `sc-build.md`
- `sc-all.md`
- `sc-fe.md`
- `sc-ui.md`
- `sc-ux.md`
- `sc-dx.md`
- `sc-ax.md`
- `sc-provider.md`
- `sc-install.md`
- `sc-help.md`
